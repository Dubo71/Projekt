<template>
  <div>
    <!-- Tutaj wprowadź jakiś element podziału komponentu -->
    <div v-for='product in products' :key='product.id'>
      <Product v-bind='product' />
    </div>
  </div>
</template>

<script>
import Product from './components/Product.vue';

export default {
  components: { Product },
  data() {
    return {
      page: 1,
      products: [],
      numberOfItems: 0,
      numberOfItemsOnPage: 0,
    };
  },
  methods: {
    fetchProducts() {
      this.$http
        .get('/book', { params: { page: this.page } })
        .then(({ data: { data, meta: { totalRecords, recordsPerPage } } }) => {
          this.products = data;
          this.numberOfItems = totalRecords;
          this.numberOfItemsOnPage = recordsPerPage;
        });
    },
  },
  mounted() {
    this.fetchProducts();
  },
};
</script>
