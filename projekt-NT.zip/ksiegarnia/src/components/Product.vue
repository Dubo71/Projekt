<template>
  <!-- TUTAJ WPROWADŹ TEMPLATE -->
  <div></div>
</template>

<script>
export default {
  props: {
    /* w PROPS umieść informacje o danych, które są potrzebne w tym komponencie
       (przekazane z rodzica) */
  },
  computed: {
    /* w COMPUTED umieść funkcje potrzebne do konwersji danych (np. zmiany formatu tekstu)  */
  },
  methods: {
    /* w METHODS umieść funkcje słuzące do wykonywania akcji */
  },
};
</script>

<style scoped lang="scss">
/* TUTAJ WPROWADŹ STYLE CSS */
</style>
